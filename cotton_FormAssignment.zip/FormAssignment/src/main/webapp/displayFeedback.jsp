<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Submitted Feedback Results</title>
</head>
<body>
    <h2>Thank You for Your Feedback!</h2>
    <p>Below is a summary of the information you submitted.</p>

    <%
        String fullname = request.getParameter("fullname");
        String email = request.getParameter("email");
        String rating = request.getParameter("rating");
        String mealtype = request.getParameter("mealtype");
        String comments = request.getParameter("comments");
    %>

    <table border="1" cellpadding="8" cellspacing="0">
        <tr><th>Field</th><th>Your Response</th></tr>
        <tr><td>Full Name</td><td><%= fullname %></td></tr>
        <tr><td>Email Address</td><td><%= email %></td></tr>
        <tr><td>Meal Rating</td><td><%= rating %></td></tr>
        <tr><td>Type of Meal Ordered</td><td><%= mealtype %></td></tr>
        <tr><td>Additional Comments</td><td><%= comments %></td></tr>
    </table>

    <br>
    <p>This information helps us improve our service and overall dining experience.</p>
</body>
</html>
